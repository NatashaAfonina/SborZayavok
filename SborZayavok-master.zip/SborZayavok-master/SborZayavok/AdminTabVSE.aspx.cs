﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SborZayavok
{
    public partial class AdminTabVSE : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // AdminDBVSEDataContext db = new AdminDBVSEDataContext();
           // BazaMasterov tab4 = new BazaMasterov();
            //spisokzayavok tab5 = new spisokzayavok();
        }
    }
}